import { connect } from 'react-redux';
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { CAPcase } from '../../helpers';
import { setSearchString } from '../../store/actions';
import style from '../../assets/styles/search-box.css';

class SearchBox extends Component {
  handleOnInputChange = (event) => {
    this.props.setSearchString(event.target.value);
  };
  render() {
    return (
      <div className={style.search_container}>
        <input
          placeholder="Where you are going?"
          className={style.search_input}
          onChange={this.handleOnInputChange}
          value={this.props.searchString}
          type="text" />
        <ul className={style.search_result}>
          {this.props.searchResult.slice(0, 6).map(link => (
            <li key={link.title}>
              <Link
                to={'/' + CAPcase(link.title)}>
                {link.title}
                {link.isSpecialOffer&& <span className={style.discount_flag}>Special Offer</span>}
              </Link>
            </li>
          ))}
          {this.props.searchResult.length <= 0
          && this.props.searchString &&
          <li className={style.error}>Sorry no result matched your search</li>}
        </ul>


      </div>
    );
  }
}

const mapStateToProps = state => ({
  searchResult: state.searchResult,
  searchString: state.searchString,
});

const mapDispatchToProps = dispatch => ({
  setSearchString: payload => dispatch(setSearchString(payload)),
});
export default connect(mapStateToProps, mapDispatchToProps)(SearchBox);
