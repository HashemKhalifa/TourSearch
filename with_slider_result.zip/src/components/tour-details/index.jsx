import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { CAPcase } from "../../helpers.js";
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
import faStar from '@fortawesome/fontawesome-free-solid/faStar';
import style from "../../assets/styles/tour-details.css";

import {
  setSearchString,
  setCurrentItem,
  nextItem,
  prevItem
} from "../../store/actions";

const StarRatings = props => (
  <div className={style.rating_stars}>
    <ul className={style.star_rating_list}>
      {new Array(5).fill(0).map((key, idx) => (
        <li className="www-rating-stars__star" key={"rating-" + idx}>
          <FontAwesomeIcon icon={faStar} />
        </li>
      ))}
    </ul>
    {props.rating && (
      <ul className={style.star_rating_list_active}>
        {new Array(Math.round(props.rating)).fill(0).map((key, idx) => (
          <li
            key={"rating-active-" + idx}
          >
            <FontAwesomeIcon icon={faStar} />
          </li>
        ))}
      </ul>
    )}
  </div>
);

// export default StarRatings;

const TourItem = props => (
  <div>
    <ul>
      <li>
        <h4>{props.title}</h4>
      </li>
      <li>
        {props.price}
        {props.currency}
      </li>
      <li>
        <StarRatings rating={props.rating} />
      </li>
      {props.isSpecialOffer && <li>Special offer</li>}
    </ul>
  </div>
);
TourItem.propTypes = {
  title: PropTypes.string.isRequired,
  price: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  currency: PropTypes.string.isRequired,
  rating: PropTypes.string.isRequired,
  isSpecialOffer: PropTypes.bool
};

class TourDetails extends Component {
  state = {
    view: false
  };

  componentDidMount() {
    if (this.props.searchResult.length === 0) {
      this.props.setCurrentItem(this.props.match.params.tour, true);
      this.setState({ view: true });
    } else {
      this.props.setCurrentItem(this.props.match.params.tour);
    }
  }

  handleNextItem = () => {
    this.props.nextItem();
    this.props.history.push(
      `/${CAPcase(this.props.searchResult[this.props.currentIndex + 1].title)}`
    );
  };
  handlePreviousItem = () => {
    this.props.prevItem();
    this.props.history.push(
      `/${CAPcase(this.props.searchResult[this.props.currentIndex - 1].title)}`
    );
  };

  render() {
    const { currentItem, currentIndex, searchResult } = this.props;
    return (
      <div className={style["tour-details"]}>
        {currentItem && <TourItem {...currentItem} />}
        {!this.state.view && (
          <div className={style.buttons}>
            <button
              className={style["prev-button"]}
              disabled={currentIndex === 0}
              onClick={this.handlePreviousItem}
            >
              Previous
            </button>
            <button
              className={style["next-button"]}
              disabled={searchResult.length === currentIndex + 1}
              onClick={this.handleNextItem}
            >
              Next
            </button>
          </div>
        )}
      </div>
    );
  }
}

TourDetails.propTypes = {
  title: PropTypes.string
};

const mapStateToProps = state => ({
  currentItem: state.currentItem,
  searchResult: state.searchResult,
  currentIndex: state.currentIndex
});

const mapDispatchToProps = dispatch => ({
  setSearchString: payload => dispatch(setSearchString(payload)),
  setCurrentItem: (payload, view) => dispatch(setCurrentItem(payload, view)),
  nextItem: payload => dispatch(nextItem(payload)),
  prevItem: payload => dispatch(prevItem(payload))
});

export default connect(mapStateToProps, mapDispatchToProps)(TourDetails);
