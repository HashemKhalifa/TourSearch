const data = require('../data.json');

export default {
  currentItem: null,
  searchResult: [],
  searchString: '',
  data: data.tours,
};
