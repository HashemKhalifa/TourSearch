export const FILTER_STRING = 'FILTER_STRING';
export const SEARCH_RESULT = 'SEARCH_RESULT';
export const CURRENT_ITEM = 'CURRENT_ITEM';
export const PREV_ITEM = 'PREV_ITEM';
export const NEXT_ITEM = 'NEXT_ITEM';

